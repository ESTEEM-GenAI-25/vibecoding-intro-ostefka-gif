import React, { useState, useCallback } from 'react';
import { Recipient, RefinedOutput } from './types';
import { refineDraft } from './services/geminiService';
import RecipientSelector from './components/RecipientSelector';
import OutputDisplay from './components/OutputDisplay';

const App: React.FC = () => {
  const [rawDraft, setRawDraft] = useState<string>('');
  const [targetRecipient, setTargetRecipient] = useState<Recipient>(Recipient.CTO);
  const [refinedOutput, setRefinedOutput] = useState<RefinedOutput | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleRefineClick = useCallback(async () => {
    if (!rawDraft.trim()) {
      setError("Please enter a draft to refine.");
      return;
    }
    setError(null);
    setIsLoading(true);
    setRefinedOutput(null);

    try {
      const result = await refineDraft(rawDraft, targetRecipient);
      setRefinedOutput(result);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("An unknown error occurred.");
      }
    } finally {
      setIsLoading(false);
    }
  }, [rawDraft, targetRecipient]);
  
  const handleDraftChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setRawDraft(e.target.value);
    if(error) setError(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 p-4 sm:p-6 lg:p-8">
      <main className="max-w-4xl mx-auto">
        <header className="text-center mb-10">
          <h1 className="text-4xl sm:text-5xl font-bold text-slate-100 pb-2">
            EchoDraft
          </h1>
          <p className="text-slate-400 text-lg">
            Transform Raw Notes into Polished Corporate Communications
          </p>
        </header>

        <blockquote className="mb-10 p-4 bg-slate-900/70 border-l-4 border-teal-500 text-slate-400 rounded-r-lg shadow-inner shadow-black/20">
          <p><strong>How it works:</strong> 1. Write your raw notes. 2. Choose the target audience. 3. Let Gemini refine your message. Then, review the analysis and copy it with one click.</p>
        </blockquote>

        <div className="space-y-6 p-6 bg-slate-900/70 border border-slate-800 rounded-xl shadow-2xl shadow-black/30">
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-teal-400 mb-3">1. Enter Raw Draft</h2>
              <textarea
                value={rawDraft}
                onChange={handleDraftChange}
                placeholder="e.g., 'The login feature is broken because the auth token isn't refreshing. Need to fix the API endpoint and maybe update the frontend library. It's causing a lot of user complaints.'"
                className="w-full h-36 p-3.5 bg-slate-800/60 border border-slate-700 rounded-md text-slate-300 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-teal-500 focus:border-teal-500 transition-all duration-200"
              />
            </div>

            <RecipientSelector selected={targetRecipient} onSelect={setTargetRecipient} />
          </div>

          <div className="pt-6 border-t border-slate-800">
            <button
              onClick={handleRefineClick}
              disabled={isLoading || !rawDraft.trim()}
              className="w-full flex items-center justify-center gap-2 p-3 text-lg font-bold bg-teal-600 text-white rounded-lg hover:bg-teal-500 disabled:bg-slate-700 disabled:text-slate-400 disabled:cursor-not-allowed transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-teal-500 shadow-lg shadow-teal-600/20"
            >
              {isLoading ? (
                <>
                  <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Refining...
                </>
              ) : (
                <>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5">
                  <path d="M10 3.5a1.5 1.5 0 0 1 3 0V4a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H2a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h3a1 1 0 0 0 1-1V3.5ZM9.5 8v-.5a.5.5 0 0 0-1 0V8a2.5 2.5 0 0 0-2.5 2.5v.5a.5.5 0 0 0 1 0v-.5a1.5 1.5 0 0 1 3 0v.5a.5.5 0 0 0 1 0v-.5A2.5 2.5 0 0 0 9.5 8Z" />
                  <path d="M7 3.5a1.5 1.5 0 0 1 3 0V4a1 1 0 0 0 1 1h3a1 1 0 0 1 1 1v.25a.75.75 0 0 1-1.5 0V7h-1.25a.75.75 0 0 1 0-1.5H14V6a.5.5 0 0 0-.5-.5h-3a1.5 1.5 0 0 1-1.5-1.5v-.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v.5A1.5 1.5 0 0 1 3.5 6H2v1h-.25a.75.75 0 0 1 0 1.5H2v-.25a.75.75 0 0 1 1.5 0V15H2v-1h.25a.75.75 0 0 1 0-1.5H2V9h1.25a.75.75 0 0 1 0 1.5H2v3.25a.75.75 0 0 1-1.5 0V15H18V9h-1.25a.75.75 0 0 1 0-1.5H18V7h-.25a.75.75 0 0 1 0-1.5H18v-.25a.5.5 0 0 0-.5-.5h-3a1.5 1.5 0 0 1-1.5-1.5v-.5a.5.5 0 0 0-1 0v.5A1.5 1.5 0 0 1 8.5 6H7V3.5Z" />
                </svg>
                Refine Draft
                </>
              )}
            </button>
          </div>
        </div>
        
        {error && (
            <div className="mt-8 p-4 bg-red-900/30 border border-red-700/50 text-red-300 rounded-lg text-center">
                <strong>Error:</strong> {error}
            </div>
        )}

        {refinedOutput && <OutputDisplay output={refinedOutput} originalDraft={rawDraft} />}

      </main>
      <footer className="text-center mt-12 pb-4 text-slate-500">
        <p className="text-sm">Powered by Google Gemini</p>
        <p className="mt-1 text-xs">Created by Olivia Stefka</p>
      </footer>
    </div>
  );
};

export default App;