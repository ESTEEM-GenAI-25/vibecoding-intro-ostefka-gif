export enum Recipient {
  CEO = "Chief Executive Officer (CEO)",
  CTO = "Chief Technology Officer (CTO)",
  Marketing = "Marketing Director",
  HR = "Human Resources (HR) Partner",
  Finance = "Financial Analyst/CFO",
  JuniorDev = "Junior Development Team",
  Sales = "Sales Team/Account Executive",
  Legal = "Legal Counsel/Compliance",
  PM = "Project Manager (PM)",
  Vendor = "External Partner/Vendor",
}

export interface ComparativeMetrics {
  original_clarity: number;
  refined_clarity: number;
  original_formality: number;
  refined_formality: number;
}

export interface RefinedOutput {
  target_recipient: Recipient;
  refined_draft: string;
  scorecard_rationale: string;
  comparative_metrics: ComparativeMetrics;
}
