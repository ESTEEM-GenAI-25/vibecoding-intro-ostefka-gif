import React, { useState } from 'react';
import { RefinedOutput } from '../types';

interface OutputDisplayProps {
  output: RefinedOutput;
  originalDraft: string;
}

const MetricBar: React.FC<{ label: string; originalValue: number; refinedValue: number }> = ({ label, originalValue, refinedValue }) => {
  const refinedPercent = (refinedValue / 10) * 100;
  const improvement = refinedValue - originalValue;

  let scoreClass = 'text-teal-400';
  let barClass = 'bg-teal-500';
  let changeIndicator = `(${improvement > 0 ? '+' : ''}${improvement})`;

  if (improvement < 0) {
    scoreClass = 'text-amber-400';
    barClass = 'bg-amber-500';
  } else if (improvement === 0) {
    changeIndicator = '';
  }


  return (
    <div className="space-y-1.5">
      <div className="flex justify-between items-baseline">
        <span className="font-medium text-slate-300">{label}</span>
        <div className="flex items-baseline space-x-2">
          <span className="font-mono text-sm text-slate-500">{originalValue} →</span>
          <strong className={`text-xl font-semibold ${scoreClass}`}>{refinedValue}</strong>
          {improvement !== 0 && <span className={`text-sm font-medium ${scoreClass}`}>{changeIndicator}</span>}
        </div>
      </div>
      <div className="w-full bg-slate-700/50 rounded-full h-2">
        <div 
          className={`${barClass} h-2 rounded-full`} 
          style={{ 
            width: `${refinedPercent}%`,
            transition: 'width 0.5s ease-in-out',
          }}
        ></div>
      </div>
    </div>
  );
};

const OutputDisplay: React.FC<OutputDisplayProps> = ({ output, originalDraft }) => {
  const [copySuccess, setCopySuccess] = useState(false);
  const [confidence, setConfidence] = useState<string | null>(null);
  
  const { comparative_metrics } = output;

  const handleCopy = () => {
    navigator.clipboard.writeText(output.refined_draft).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000); // Reset after 2 seconds
    }, (err) => {
      console.error('Could not copy text: ', err);
    });
  };

  const renderMarkdown = (text: string) => {
    let html = text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-slate-100">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/^- (.*)/gm, '<li class="relative pl-6 before:content-[\'–\'] before:absolute before:left-0 before:text-teal-400 before:font-bold">$1</li>');

    if (html.includes('<li')) {
        html = '<ul class="space-y-2">' + html + '</ul>'
    }

    return { __html: html };
  };
    
  return (
    <div className="mt-10 space-y-8 animate-fade-in">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-400 mb-3">Original Draft</h3>
          <div className="p-4 bg-slate-900/70 border border-slate-800 rounded-lg text-slate-400 leading-relaxed h-full">
            <pre className="whitespace-pre-wrap font-sans text-sm">{originalDraft}</pre>
          </div>
        </div>
        <div>
          <h3 className="text-lg font-semibold text-teal-400 mb-3">Refined Draft for <span className="text-white font-bold">{output.target_recipient}</span></h3>
          <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg prose-p:my-0 prose-ul:my-0 text-slate-300 leading-relaxed h-full"
               dangerouslySetInnerHTML={renderMarkdown(output.refined_draft)}
          >
          </div>
        </div>
      </div>

      <div className="p-6 bg-slate-900/70 border border-slate-800 rounded-xl shadow-2xl shadow-black/30 space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-200 mb-4">Analysis</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-8 gap-y-6">
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700/50 space-y-4">
                <h4 className="font-semibold text-slate-300">Impact Metrics</h4>
                <MetricBar label="Clarity" originalValue={comparative_metrics.original_clarity} refinedValue={comparative_metrics.refined_clarity} />
                <MetricBar label="Formality" originalValue={comparative_metrics.original_formality} refinedValue={comparative_metrics.refined_formality} />
              </div>
              <div className="p-4 bg-slate-800/50 rounded-lg border border-slate-700/50">
                <h4 className="font-semibold text-slate-300">Rationale</h4>
                <p className="mt-2 text-slate-400 leading-relaxed text-sm">
                    {output.scorecard_rationale}
                </p>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 pt-6 border-t border-slate-800">
              <div className="w-full sm:w-auto">
                  <h4 className="text-md font-medium text-slate-300 mb-2 text-center sm:text-left">Rate this refinement:</h4>
                  <div className="flex justify-center sm:justify-start gap-2">
                      {['Low', 'Medium', 'High'].map(level => (
                          <button
                              key={level}
                              onClick={() => setConfidence(level)}
                              className={`px-3 py-1.5 rounded-md border transition-all text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 ${
                                  confidence === level 
                                  ? 'bg-green-600 border-green-500 text-white'
                                  : 'bg-slate-700 border-slate-600 hover:bg-slate-600/80 text-slate-300'
                              }`}
                          >
                              {level}
                          </button>
                      ))}
                  </div>
                  {confidence && <p className="text-center sm:text-left text-green-400 text-xs mt-2 transition-opacity">Thank you for your feedback!</p>}
              </div>

              <button
                  onClick={handleCopy}
                  className="w-full sm:w-auto px-6 py-2.5 text-md font-bold bg-teal-600 text-white rounded-lg hover:bg-teal-500 disabled:bg-slate-600 transition-all focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-900 focus:ring-teal-500 shadow-lg shadow-teal-600/20"
              >
                  {copySuccess ? 'Copied!' : 'Copy to Clipboard'}
              </button>
          </div>
      </div>
    </div>
  );
};

export default OutputDisplay;