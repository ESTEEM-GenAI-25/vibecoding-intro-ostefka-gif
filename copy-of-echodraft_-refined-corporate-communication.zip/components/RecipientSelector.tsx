import React from 'react';
import { Recipient } from '../types';

interface RecipientSelectorProps {
  selected: Recipient;
  onSelect: (recipient: Recipient) => void;
}

const recipientOptions = [
  { id: Recipient.CEO, label: "CEO" },
  { id: Recipient.CTO, label: "CTO" },
  { id: Recipient.Marketing, label: "Marketing" },
  { id: Recipient.HR, label: "HR Partner" },
  { id: Recipient.Finance, label: "Finance / CFO" },
  { id: Recipient.JuniorDev, label: "Junior Dev Team" },
  { id: Recipient.Sales, label: "Sales Team" },
  { id: Recipient.Legal, label: "Legal" },
  { id: Recipient.PM, label: "Project Manager" },
  { id: Recipient.Vendor, label: "External Vendor" },
];


const RecipientSelector: React.FC<RecipientSelectorProps> = ({ selected, onSelect }) => {
  return (
    <div>
      <h2 className="text-lg font-semibold text-teal-400 mb-3">2. Select Target Recipient</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
        {recipientOptions.map((option) => (
          <button
            key={option.id}
            onClick={() => onSelect(option.id)}
            className={`p-3 rounded-md border text-center transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-slate-950 focus:ring-teal-500 ${
              selected === option.id
                ? "bg-teal-600 border-teal-500 text-white shadow-md shadow-teal-600/20"
                : "bg-slate-800/60 border-slate-700 hover:bg-slate-700/80 hover:border-slate-600 text-slate-300"
            }`}
          >
            <span className="font-semibold text-sm">{option.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default RecipientSelector;