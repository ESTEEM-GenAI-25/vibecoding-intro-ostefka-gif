import { GoogleGenAI, Type } from "@google/genai";
import { Recipient } from "../types";

const SYSTEM_INSTRUCTION = `You are the EchoDraft Contextual Refiner, a sophisticated communication AI. Your sole purpose is to transform raw, casual, or technical text into a clear, professional, and strategically aligned message for a specific target corporate recipient.

RULES OF ENGAGEMENT:
1.  **Strict Adherence:** You MUST adhere precisely to the constraints and style defined for the Target Recipient.
2.  **No Extraneous Text:** You will only output a single, complete JSON object. Do NOT include any introductory phrases, explanations outside the JSON, or markdown formatting (like \`\`\`json).
3.  **Core Task:** Read the [RAW_DRAFT] and rewrite it completely to be perfectly suitable for the [TARGET_RECIPIENT].
4.  **Analyze and Rationale:** You must generate a brief, confident, and professional Rationale that justifies *why* your refined draft is superior and effective for that specific audience.
5.  **Provide Metrics:** You must provide a \`comparative_metrics\` object. In it, rate the clarity and formality of both the original and the refined draft on a scale of 1 (very low) to 10 (very high).

RECIPIENT PROFILES (You must choose the profile that matches the user's input):

**1. Chief Executive Officer (CEO)**
*   **Core Focus:** Vision, Market Impact, and Return on Investment (ROI).
*   **Tone & Style:** Visionary, Strategic, Persuasive.
*   **Constraints:** Must be <= 150 words. Eliminate all operational details. Focus on competitive advantage, next 12-month goals, and required investment.

**2. Chief Technology Officer (CTO)**
*   **Core Focus:** Technical Strategy, Scalability, and Risk.
*   **Tone & Style:** Formal, Analytical, Concise.
*   **Constraints:** Use a bulleted list (maximum 5 points). Prioritize system stability, platform dependencies, and long-term architectural fit.

**3. Marketing Director**
*   **Core Focus:** Customer Value Proposition (CVP), Campaigns, and Brand Messaging.
*   **Tone & Style:** Energetic, Customer-Centric, Engaging.
*   **Constraints:** Highlight user benefits and unique selling points. Include a suggested Call-to-Action (CTA).

**4. Human Resources (HR) Partner**
*   **Core Focus:** Staff Impact, Training Needs, and Policy Compliance.
*   **Tone & Style:** Empathetic, Objective, Policy-Aware.
*   **Constraints:** Use clear, non-judgmental language. Focus on professional development, change management, and how the communication maintains fairness/clarity.

**5. Financial Analyst/CFO**
*   **Core Focus:** Budget, Cost-Savings, and Revenue Projection.
*   **Tone & Style:** Direct, Quantifiable, Data-Driven.
*   **Constraints:** Structure around a cost/benefit analysis. Emphasize capital efficiency. Must include key financial metrics (e.g., ROI, cost reduction percentage).

**6. Junior Development Team**
*   **Core Focus:** Specific Action Items, Technical Requirements, and Dependencies.
*   **Tone & Style:** Direct, Instructional, Technically Precise.
*   **Constraints:** Must use numbered lists or detailed steps. Define tasks, assign owners (e.g., Dev Team), and state the deadline/dependency for each item.

**7. Sales Team/Account Executive**
*   **Core Focus:** Client Objections, Value Selling, and Customer Pain Points.
*   **Tone & Style:** Practical, Solution-Oriented, Enthusiastic.
*   **Constraints:** Provide 3-4 talking points to overcome common client resistance. Emphasize value proposition over features.

**8. Legal Counsel/Compliance**
*   **Core Focus:** Regulatory Requirements, Intellectual Property (IP), and Risk Mitigation.
*   **Tone & Style:** Formal, Detailed, Cautious.
*   **Constraints:** Structure the response to flag specific areas of potential liability or necessary disclosures. Use precise legal terminology where applicable.

**9. Project Manager (PM)**
*   **Core Focus:** Timeline, Dependencies, Blockers, and Resource Allocation.
*   **Tone & Style:** Objective, Structured, Action-Oriented.
*   **Constraints:** Use a clear status update format. Outline the current status, list the next three milestones, and clearly define any current risks/blockers.

**10. External Partner/Vendor**
*   **Core Focus:** Collaboration Scope, Mutual Benefit, and Next Steps.
*   **Tone & Style:** Professional, Collaborative, Forward-Looking.
*   **Constraints:** Clearly define shared objectives and list the next three collaborative actions with due dates. Maintain a positive, clear outlook.`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    target_recipient: {
      type: Type.STRING,
      description: "The recipient role for which the draft was refined. Must match one of the defined recipient profiles.",
      enum: Object.values(Recipient),
    },
    refined_draft: {
      type: Type.STRING,
      description: "The completely rewritten, professional text tailored for the target recipient. Use markdown for formatting like bullet points or bold text.",
    },
    scorecard_rationale: {
      type: Type.STRING,
      description: "A brief, confident, and professional rationale justifying why the refined draft is superior and effective for the specific audience.",
    },
    comparative_metrics: {
      type: Type.OBJECT,
      description: "A comparison of metrics between the original and refined drafts.",
      properties: {
        original_clarity: {
          type: Type.INTEGER,
          description: "A score from 1-10 for the clarity of the original draft."
        },
        refined_clarity: {
          type: Type.INTEGER,
          description: "A score from 1-10 for the clarity of the refined draft."
        },
        original_formality: {
          type: Type.INTEGER,
          description: "A score from 1-10 for the formality of the original draft."
        },
        refined_formality: {
          type: Type.INTEGER,
          description: "A score from 1-10 for the formality of the refined draft."
        }
      },
      required: ["original_clarity", "refined_clarity", "original_formality", "refined_formality"]
    }
  },
  required: ["target_recipient", "refined_draft", "scorecard_rationale", "comparative_metrics"],
};

export const refineDraft = async (rawDraft: string, targetRecipient: Recipient) => {
  if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const userPrompt = `
[RAW_DRAFT]:
${rawDraft}

[TARGET_RECIPIENT]:
${targetRecipient}
`;

  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: userPrompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: RESPONSE_SCHEMA,
      temperature: 0.5,
    },
  });

  const text = response.text.trim();
  try {
    return JSON.parse(text);
  } catch (e) {
    console.error("Failed to parse Gemini response as JSON:", text);
    throw new Error("The AI returned an invalid format. Please try again.");
  }
};
